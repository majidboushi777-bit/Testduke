import { getUser } from "@netlify/identity";
// Order intake and manager workflow. Supabase service credentials remain server-side.
const SUPABASE_URL = Netlify.env.get('SUPABASE_URL') || 'https://xgfavuzzhtlzfwprbvav.supabase.co';
const SERVICE_KEY = Netlify.env.get('SUPABASE_SERVICE_ROLE_KEY');
const ADIN_URL = Netlify.env.get('ADIN_API_URL') || 'https://adinapp.ir/api/api.php';
const ADMIN_EMAIL = 'majidboushi@gmail.com';
const json = (data, status=200) => new Response(JSON.stringify(data), {status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store'}});
async function isAdmin(){try{const user=await getUser();return String(user?.email||'').trim().toLowerCase()===ADMIN_EMAIL}catch{return false}}
async function db(path,opts={}){if(!SERVICE_KEY)throw new Error('کلید اتصال دیتابیس در تنظیمات سرور تعریف نشده است.');const r=await fetch(`${SUPABASE_URL}/rest/v1/${path}`,{...opts,headers:{apikey:SERVICE_KEY,Authorization:`Bearer ${SERVICE_KEY}`,'Content-Type':'application/json',Prefer:'return=representation',...(opts.headers||{})},signal:AbortSignal.timeout(15000)});const t=await r.text();let d;try{d=t?JSON.parse(t):null}catch{d={message:t}}if(!r.ok)throw new Error(d?.message||d?.hint||'خطای دیتابیس');return d;}
function cleanText(v,max=500){return String(v??'').trim().slice(0,max);}
export default async (req)=>{
 try{
  if(req.method==='POST'){
   const b=await req.json();
   const name=cleanText(b.customer_name,120),phone=cleanText(b.phone,20),province=cleanText(b.province,80),city=cleanText(b.city,80),address=cleanText(b.address,1000),postal=cleanText(b.postal_code,20);
   if(name.length<3||!/^09\d{9}$/.test(phone)||!province||!city||address.length<8||!/^\d{10}$/.test(postal))return json({error:'اطلاعات مشتری یا نشانی کامل نیست.'},400);
   const raw=Array.isArray(b.items)?b.items:[];if(!raw.length||raw.length>40)return json({error:'سبد خرید معتبر نیست.'},400);
   const items=raw.map(x=>({product_id:cleanText(x.product_id,80),sku_id:cleanText(x.sku_id,80)||null,title:cleanText(x.title,180),qty:Math.max(0,Math.min(99,Math.floor(Number(x.qty)||0))),unit_price:Math.max(0,Number(x.unit_price)||0)}));
   if(items.some(x=>!x.product_id||x.qty<1))return json({error:'شناسه کالا یا تعداد یکی از اقلام معتبر نیست.'},400);
   const subtotal=items.reduce((s,x)=>s+x.qty*x.unit_price,0);if(!Number.isFinite(subtotal)||subtotal<=0)return json({error:'مبلغ سفارش معتبر نیست.'},400);const cfgRows=await db('site_settings?select=value&key=eq.storefront');const cfg=cfgRows?.[0]?.value||{};const threshold=Math.max(0,Number(cfg.free_shipping_threshold)||0),shippingFee=(threshold>0&&subtotal>=threshold)?0:Math.max(0,Number(cfg.shipping_fee)||0);
   const request_key=cleanText(b.request_key,80)||`WEB-${Date.now()}-${Math.random().toString(36).slice(2,8)}`;
   const existing=await db(`orders?select=id,order_number,request_key,status,total&request_key=eq.${encodeURIComponent(request_key)}&limit=1`);
   if(existing?.[0]){const o=existing[0];return json({ok:true,duplicate:true,order:{id:o.id,order_number:o.order_number,request_key:o.request_key,status:o.status,total:o.total,shipping_fee:o.shipping_fee}},200);}
   const rows=await db('orders',{method:'POST',body:JSON.stringify({customer_name:name,phone,email:cleanText(b.email,160)||null,province,city,address,postal_code:postal,customer_note:cleanText(b.customer_note,1000)||null,items,subtotal,shipping_fee:shippingFee,total:subtotal+shippingFee,status:'pending_confirmation',request_key})});
   const o=Array.isArray(rows)?rows[0]:rows;return json({ok:true,order:{id:o.id,order_number:o.order_number,request_key:o.request_key,status:o.status,total:o.total,shipping_fee:o.shipping_fee}},201);
  }
  if(req.method==='GET'){
   const url=new URL(req.url);
   if(url.searchParams.get('track')==='1'){
    const rawNumber=cleanText(url.searchParams.get('order_number'),40).toUpperCase().replace(/^DK\s*/,'').replace(/[^A-Z0-9-]/g,'');
    const phone=cleanText(url.searchParams.get('phone'),20).replace(/[^0-9]/g,'');
    if(!rawNumber||!/^09\d{9}$/.test(phone))return json({error:'شماره سفارش یا موبایل معتبر نیست.'},400);
    const rows=await db(`orders?select=order_number,status,created_at,adin_invoice_number&order_number=eq.${encodeURIComponent(rawNumber)}&phone=eq.${encodeURIComponent(phone)}&limit=1`);
    return json({order:rows?.[0]||null});
   }
   if(!await isAdmin())return json({error:'دسترسی مدیریت تأیید نشد.'},401);
   const rows=await db('orders?select=*&order=created_at.desc&limit=200');return json({orders:rows||[]});
  }
  if(req.method==='PATCH'){
   if(!await isAdmin())return json({error:'دسترسی مدیریت تأیید نشد.'},401);
   const b=await req.json(),id=cleanText(b.id,80),action=cleanText(b.action,30);if(!id)return json({error:'شناسه سفارش نامعتبر است.'},400);
   const found=await db(`orders?select=*&id=eq.${encodeURIComponent(id)}&limit=1`);const order=found?.[0];if(!order)return json({error:'سفارش پیدا نشد.'},404);
   if(action==='cancel'){
    if(order.adin_invoice_id)return json({error:'این سفارش در آدین فاکتور شده است؛ لغو خودکار مجاز نیست.'},409);
    const out=await db(`orders?id=eq.${encodeURIComponent(id)}`,{method:'PATCH',body:JSON.stringify({status:'cancelled',admin_note:cleanText(b.admin_note,1000)||null,updated_at:new Date().toISOString()})});return json({ok:true,order:out?.[0]});
   }
   if(action!=='confirm')return json({error:'عملیات نامعتبر است.'},400);
   if(order.adin_invoice_id||['sent_to_adin','confirmed'].includes(order.status))return json({error:'این سفارش قبلاً به آدین ارسال شده است.',invoice_id:order.adin_invoice_id},409);
   if(order.status==='cancelled')return json({error:'سفارش لغوشده قابل تأیید نیست.'},409);
   const apiKey=Netlify.env.get('ADIN_API_KEY');if(!apiKey)return json({error:'کلید API آدین در تنظیمات سرور موجود نیست.'},503);
   const adinItems=(order.items||[]).map(x=>({product_id:x.product_id,...(x.sku_id?{sku_id:x.sku_id}:{}),qty:x.qty}));
   const payload={action:'create_online_order',order_key:String(order.request_key||`WEB-${order.order_number}`),customer:{name:order.customer_name,phone:order.phone,address:order.address,postal_code:order.postal_code},items:adinItems,shipping_cost:Number(order.shipping_fee)||0,check_stock:'1',price_field:'sell_price',trust_client_price:'0',info:`سفارش سایت دوک شماره ${order.order_number}`};
   const ar=await fetch(ADIN_URL,{method:'POST',headers:{Authorization:`Bearer ${apiKey}`,'Content-Type':'application/json',Accept:'application/json'},body:JSON.stringify(payload),signal:AbortSignal.timeout(30000)});
   const raw=await ar.text();let ad;try{ad=JSON.parse(raw)}catch{return json({error:'پاسخ آدین قابل خواندن نبود؛ سفارش در وضعیت خطا باقی ماند.'},502)};
   if(!ar.ok||ad?.result==='error'||ad?.success===false||ad?.error){await db(`orders?id=eq.${encodeURIComponent(id)}`,{method:'PATCH',body:JSON.stringify({status:'adin_error',admin_note:cleanText(ad?.message||ad?.error||'خطای آدین',1000),updated_at:new Date().toISOString()})});return json({error:cleanText(ad?.message||ad?.error||'ثبت فاکتور در آدین ناموفق بود.',500)},502)}
   const invoiceId=ad.invoice_id??ad.id??ad.data?.invoice_id??ad.data?.id??'';const invoiceNo=ad.invoice_number??ad.data?.invoice_number??ad.number??'';
   if(!invoiceId&&!invoiceNo)return json({error:'آدین پاسخ موفق داد اما شناسه فاکتور در پاسخ پیدا نشد. برای جلوگیری از فاکتور تکراری، سفارش را دوباره تأیید نکن و پاسخ آدین بررسی شود.'},502);
   const out=await db(`orders?id=eq.${encodeURIComponent(id)}`,{method:'PATCH',body:JSON.stringify({status:'sent_to_adin',adin_invoice_id:String(invoiceId||invoiceNo),adin_invoice_number:String(invoiceNo||invoiceId),confirmed_at:new Date().toISOString(),admin_note:cleanText(b.admin_note,1000)||null,updated_at:new Date().toISOString()})});
   return json({ok:true,order:out?.[0],adin:ad});
  }
  return json({error:'Method not allowed'},405);
 }catch(e){return json({error:e?.message||'خطای سرور'},500)}
};
