import { getUser } from '@netlify/identity';
// Dook prize wheel: all customer records, referral credits and random prizes are stored server-side.
const SUPABASE_URL = Netlify.env.get('SUPABASE_URL') || 'https://xgfavuzzhtlzfwprbvav.supabase.co';
const SERVICE_KEY = Netlify.env.get('SUPABASE_SERVICE_ROLE_KEY');
const ADMIN_EMAIL = 'majidboushi@gmail.com';
const json = (data, status=200) => new Response(JSON.stringify(data), {
  status,
  headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' }
});
function normalizePhone(value) {
  return String(value || '').replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d)).replace(/[^0-9]/g, '');
}
async function rpc(name, body) {
  if (!SERVICE_KEY) throw new Error('کلید اتصال دیتابیس در تنظیمات سرور موجود نیست.');
  const response = await fetch(`${SUPABASE_URL}/rest/v1/rpc/${name}`, {
    method: 'POST',
    headers: { apikey: SERVICE_KEY, Authorization: `Bearer ${SERVICE_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(12000)
  });
  const raw = await response.text();
  let data;
  try { data = raw ? JSON.parse(raw) : null; } catch { data = { message: raw }; }
  if (!response.ok) throw new Error(data?.message || data?.hint || 'ارتباط با دیتابیس ناموفق بود.');
  return data;
}
async function allow(req, action) {
  const rawIp = req.headers.get('x-nf-client-connection-ip') || req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'unknown-client';
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(rawIp));
  const ipHash = Array.from(new Uint8Array(digest), b => b.toString(16).padStart(2, '0')).join('');
  const result = await rpc('dook_wheel_allow_request', {
    p_ip_hash: ipHash,
    p_action: action,
    p_max: action === 'register' ? 30 : 60,
    p_window_seconds: action === 'register' ? 86400 : 3600
  });
  return result === true;
}
export default async request => {
  try {
    if (request.method === 'GET') {
      let user = null; try { user = await getUser(); } catch {}
      if (String(user?.email || '').trim().toLowerCase() !== ADMIN_EMAIL) return json({ error: 'دسترسی مدیریت تأیید نشد.' }, 401);
      if (!SERVICE_KEY) throw new Error('کلید اتصال دیتابیس در تنظیمات سرور موجود نیست.');
      const base = { apikey: SERVICE_KEY, Authorization: `Bearer ${SERVICE_KEY}` };
      const prizesResponse = await fetch(`${SUPABASE_URL}/rest/v1/dook_wheel_prizes?select=claim_code,prize_code,created_at,customer_id&order=created_at.desc&limit=300`, { headers: base, signal: AbortSignal.timeout(12000) });
      const prizes = await prizesResponse.json().catch(() => []);
      if (!prizesResponse.ok) throw new Error('دریافت جوایز ناموفق بود.');
      const ids = [...new Set((prizes || []).map(x => x.customer_id).filter(Boolean))];
      let customers = [];
      if (ids.length) {
        const inFilter = ids.map(id => String(id).replace(/[^a-f0-9-]/gi, '')).join(',');
        const customerUrl = new URL(`${SUPABASE_URL}/rest/v1/dook_wheel_customers`);
        customerUrl.searchParams.set('select', 'id,phone,referral_code');
        customerUrl.searchParams.set('id', `in.(${inFilter})`);
        const customersResponse = await fetch(customerUrl, { headers: base, signal: AbortSignal.timeout(12000) });
        customers = await customersResponse.json().catch(() => []);
        if (!customersResponse.ok) throw new Error('دریافت اطلاعات مشتریان جوایز ناموفق بود.');
      }
      const byId = Object.fromEntries((customers || []).map(x => [x.id, x]));
      return json({ prizes: (prizes || []).map(x => ({ ...x, phone: byId[x.customer_id]?.phone || '', referral_code: byId[x.customer_id]?.referral_code || '' })) });
    }
    if (request.method !== 'POST') return json({ error: 'Method not allowed' }, 405);
    const body = await request.json();
    const action = String(body?.action || '');
    if (!['register', 'spin'].includes(action)) return json({ error: 'درخواست نامعتبر است.' }, 400);
    const phone = normalizePhone(body?.phone);
    if (!/^09\d{9}$/.test(phone)) return json({ error: 'شماره موبایل باید ۱۱ رقم و با ۰۹ شروع شود.' }, 400);
    if (!await allow(request, action)) return json({ error: 'تعداد درخواست‌ها از این اینترنت بیش از حد مجاز است. کمی بعد دوباره تلاش کن.' }, 429);

    if (action === 'register') {
      const referral = String(body?.referral_code || '').trim().toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 16);
      const result = await rpc('dook_wheel_register', { p_phone: phone, p_referral_code: referral || null });
      return json(result || { ok: false, error: 'ثبت شماره انجام نشد.' });
    }

    const requestId = String(body?.request_id || '');
    if (!/^[A-Za-z0-9_-]{12,100}$/.test(requestId)) return json({ error: 'شناسه چرخش معتبر نیست.' }, 400);
    const result = await rpc('dook_wheel_spin', { p_phone: phone, p_request_id: requestId });
    if (result?.error === 'no_spins') return json({ ...result, message: 'شانسی برای چرخش باقی نمانده است.' }, 409);
    return json(result || { ok: false, error: 'چرخش انجام نشد.' });
  } catch (error) {
    const message = String(error?.message || 'خطای سرور');
    if (message.includes('invalid_phone')) return json({ error: 'شماره موبایل معتبر نیست.' }, 400);
    if (message.includes('customer_not_registered')) return json({ error: 'ابتدا شماره موبایلت را ثبت کن.' }, 404);
    return json({ error: message }, 500);
  }
};
