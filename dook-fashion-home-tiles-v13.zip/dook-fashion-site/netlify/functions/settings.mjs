import { getUser } from "@netlify/identity";
// Public storefront settings + admin-only updates.
const URL = Netlify.env.get('SUPABASE_URL') || 'https://xgfavuzzhtlzfwprbvav.supabase.co';
const ADMIN = 'majidboushi@gmail.com';
const BUCKET = 'dook-product-gallery';
const json=(d,s=200)=>new Response(JSON.stringify(d),{status:s,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store'}});
async function admin(){try{const user=await getUser();return String(user?.email||'').trim().toLowerCase()===ADMIN}catch{return false}}
const defaults={store_name:'دوک',tagline:'پوشاک سنتی و هنری',announcement:'🚚 فروش آنلاین · ارسال به سراسر ایران · پاسخگویی ۹ تا ۱۷',phone1:'02191556078',phone2:'09025563470',instagram:'https://www.instagram.com/dook',telegram:'https://t.me/dook',eitaa:'https://eitaa.com/dook',bale:'https://ble.ir/dook',shipping_fee:0,free_shipping_threshold:0,shipping_text:'ارسال به سراسر ایران',home_title:'هنرِ پوشیدن، اصالتِ زندگی',home_subtitle:'پوشاک ایرانی با ارسال به سراسر ایران',accent_color:'#542713',background_color:'#fbf7f1',promo_image:'',promo_link:'#shop',show_categories:true,show_promo:true,show_featured:true,show_fabric:true,show_new_products:true,slides:[{image:'',title:'',text:''},{image:'',title:'',text:''},{image:'',title:'',text:''}],pages:{about:'',shipping:'',returns:'',faq:'',size:'',fabric:'',installments:''}};
async function sb(path,opts={}){const k=Netlify.env.get('SUPABASE_SERVICE_ROLE_KEY');if(!k)throw new Error('کلید دیتابیس در تنظیمات Netlify موجود نیست.');const r=await fetch(`${URL}/rest/v1/${path}`,{...opts,headers:{apikey:k,Authorization:`Bearer ${k}`,'Content-Type':'application/json',Prefer:'return=representation',...(opts.headers||{})},signal:AbortSignal.timeout(15000)});const t=await r.text();let d;try{d=t?JSON.parse(t):null}catch{d=t}if(!r.ok)throw new Error(d?.message||'خطای دیتابیس');return d}
function normalize(x){const o={...defaults,...(x||{})};o.slides=Array.isArray(o.slides)?o.slides.slice(0,6):defaults.slides;for(const k of ['show_categories','show_promo','show_featured','show_fabric','show_new_products'])o[k]=o[k]!==false;o.pages={...defaults.pages,...(o.pages||{})};for(const k of ['shipping_fee','free_shipping_threshold'])o[k]=Math.max(0,Math.min(100000000,Number(o[k])||0));for(const k of ['store_name','tagline','announcement','phone1','phone2','instagram','telegram','eitaa','bale','shipping_text','home_title','home_subtitle','promo_image','promo_link','accent_color','background_color'])o[k]=String(o[k]??'').slice(0,2000);return o}
export default async req=>{try{if(req.method==='GET'){const rows=await sb('site_settings?select=key,value');const row=(rows||[]).find(x=>x.key==='storefront');return json({settings:normalize(row?.value||{})})}if(req.method==='POST'){
      if(!await admin())return json({error:'دسترسی مدیریت تأیید نشد.'},401);
      const form=await req.formData(),file=form.get('image');
      if(!file||typeof file.arrayBuffer!=='function')return json({error:'فایل تصویر انتخاب نشده است.'},400);
      if(!String(file.type||'').startsWith('image/'))return json({error:'فقط فایل تصویری مجاز است.'},400);
      if(file.size>4*1024*1024)return json({error:'حجم عکس باید کمتر از ۴ مگابایت باشد.'},400);
      const ext=({'image/jpeg':'jpg','image/png':'png','image/webp':'webp','image/gif':'gif'})[file.type];
      if(!ext)return json({error:'فرمت مجاز: JPG، PNG، WEBP یا GIF.'},400);
      const path=`site-assets/${crypto.randomUUID()}.${ext}`;
      const k=Netlify.env.get('SUPABASE_SERVICE_ROLE_KEY');
      const up=await fetch(`${URL}/storage/v1/object/${BUCKET}/${path.split('/').map(encodeURIComponent).join('/')}`,{method:'POST',headers:{apikey:k,Authorization:`Bearer ${k}`,'content-type':file.type,'x-upsert':'false'},body:await file.arrayBuffer(),signal:AbortSignal.timeout(20000)});
      if(!up.ok){const msg=await up.text();throw new Error(`بارگذاری تصویر در فضای ذخیره‌سازی ناموفق بود: ${msg.slice(0,220)}`)}
      const publicUrl=`${URL}/storage/v1/object/public/${BUCKET}/${path.split('/').map(encodeURIComponent).join('/')}`;
      return json({ok:true,url:publicUrl});
    }
    if(req.method==='PUT'){if(!await admin())return json({error:'دسترسی مدیریت تأیید نشد.'},401);const body=await req.json();const value=normalize(body);const rows=await sb('site_settings?on_conflict=key',{method:'POST',headers:{Prefer:'resolution=merge-duplicates,return=representation'},body:JSON.stringify({key:'storefront',value,updated_at:new Date().toISOString()})});return json({ok:true,settings:value})}return json({error:'Method not allowed'},405)}catch(e){return json({error:e.message||'خطای سرور'},500)}};
